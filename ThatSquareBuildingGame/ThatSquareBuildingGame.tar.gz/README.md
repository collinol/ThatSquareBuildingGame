# ThatSquareBuildingGame

Arrow keys to move up left right and down
space bar rotates piece
'q' to place the piece

timer out will drop piece directly down as far as possible.

Goal: clear pieces by forming a complete 4x4 square or larger
Don't run out of room

# To Play

Download ThatSquareBuildingGame.tar.gz
extract in chosen folder
from that folder, run: 

$ java ThatSquareBuildingGame





